// Types for Gereja Management System

export type MasterDataCategory =
  | 'jabatan_pelayanan'
  | 'pelkat'
  | 'jenis_persembahan'
  | 'kategori_aset'
  | 'jenis_ibadah'
  | 'kategori_ibadah'
  | 'daftar_pelayan'
  | 'metode_pembayaran'
  | 'status_sakramen'
  | 'jenis_jadwal_ibadah'
  | 'buku_nyanyian'
  | 'tipe_nyanyian_ibadah'
  | 'tempat_sakramen'
  | 'prioritas_pengumuman'
  | 'status_peminjaman_ruangan'
  | 'status_distribusi_bantuan'
  | 'status_permohonan_surat'
  | 'tipe_atestasi'
  | 'status_event'
  | 'status_pernikahan'
  | 'tipe_keanggotaan'
  | 'golongan_darah'
  | 'jenis_kegiatan'
  | 'jenis_pelayanan'
  | 'kategori_bantuan'
  | 'pendidikan'
  | 'jenis_surat_keluar'
  | 'jenis_surat_masuk';

export interface MasterDataItem {
  id: string;
  category: MasterDataCategory;
  value: string;
  label: string;
  isActive: boolean;
  order: number;
  createdAt: string;
  // Hanya relevan untuk category === 'metode_pembayaran': menandai apakah metode ini
  // mendukung pemilihan Kode QRIS & field referensi QRIS/Transfer di form Persembahan
  // Digital. Dibuat sebagai flag data-driven (bukan cek string label 'QRIS'/'Transfer'
  // yang hardcode) supaya tetap benar walau admin me-rename label metode pembayaran.
  // Opsional & backward-compatible -- item lama tanpa field ini di-fallback lewat
  // heuristik keyword di OfferingsQRIS.tsx (lihat isQrisCapablePaymentMethod).
  isQrisEligible?: boolean;
}

export type UserRole = 'Admin' | 'Majelis' | 'Ketua Sektor' | 'Operator';
export type PermissionKey = 'view' | 'create' | 'edit' | 'delete' | 'approve' | 'export';

export interface User {
  id: string;
  name: string;
  email: string;
  username: string;
  password: string;
  role: UserRole;
  isActive: boolean;
  assignedSectorId?: string; // Khusus role Ketua Sektor — ID sektor yang boleh ia kelola (edit/hapus)
  mustChangePassword?: boolean; // true untuk user hasil seed default -- lihat PUT /api/auth/change-password
}

export type MembershipType = 'Warga Jemaat' | 'Warga Tamu' | 'Simpatisan';

export interface Member {
  id: string;
  // Identitas
  familyCode?: string; // Kode Keluarga
  memberNumber?: string; // No Induk
  firstName: string; // Nama Pertama
  lastName: string; // Nama Belakang
  fullName: string; // Nama Lengkap (computed)
  familyName?: string; // Nama Keluarga
  gender: 'Laki-laki' | 'Perempuan';
  familyRole: string; // Hubungan Keluarga
  familyRoleOther?: string; // Status hubungan jika "Lainnya"
  
  // Data Kelahiran
  birthPlace?: string; // Tempat Lahir
  birthDate: string;
  age: number; // Usia (otomatis)
  
  // Data Baptis & Sidi
  baptismStatus?: 'Sudah' | 'Belum'; // Status Baptis
  baptismPlace?: string; // Tempat Baptis
  baptismDate?: string; // Tanggal Baptis
  sidiStatus?: 'Sudah' | 'Belum'; // Status Sidi
  sidiPlace?: string; // Tempat Sidi
  sidiDate?: string; // Tanggal Sidi
  
  // Data Pernikahan
  maritalStatus?: 'Belum Menikah' | 'Menikah' | 'Duda' | 'Janda'; // Status Nikah
  marriageDateChurch?: string; // Tgl Nikah Gereja
  marriageDateCivil?: string; // Tgl Nikah Sipil
  
  // Data Kesehatan & Pendidikan
  bloodType?: 'A' | 'B' | 'AB' | 'O' | 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-'; // Gol. Darah
  education?: string; // Pendidikan Terakhir
  degree?: string; // Gelar
  major?: string; // Jurusan
  
  // Data Pekerjaan
  occupation?: string; // Pekerjaan
  profession?: string; // Profesi
  workplace?: string; // Tempat Kerja
  
  // Pengalaman & Kompetensi
  organizationExperience?: string; // Pengalaman Organisasi
  churchExperience?: string; // Pengalaman Gerejawi
  languageSkills?: string; // Penguasaan Bahasa
  skills?: string; // Kompetensi-Skill
  
  // Kontak
  homePhone?: string; // Telp Rumah
  phone?: string; // Handphone
  email?: string;
  
  // Data Gereja
  membershipType?: MembershipType; // Status Keanggotaan (BARU)
  position?: string; // Posisi Jabatan
  // Status Pelkat resmi (PELKAT-PA/PT/GP/PKB/PKP/PKLU, lih. MemberDatabase.tsx)
  // dipakai untuk sensus/laporan demografi. Ini SENGAJA independen dari
  // keanggotaan komisi/unit pelayanan (Ministry.memberIds di bawah) — kategori
  // Ministry (MinistryManagement.tsx CATEGORY_CONFIG) tidak 1:1 dengan 6 Pelkat
  // resmi (mis. tidak ada kategori Ministry utk PA/PT), jadi keduanya tidak
  // digabung/disinkronkan otomatis. Lihat catatan di Ministry.memberIds.
  pelkatStatus?: string; // Status Pelkat
  familyId: string;
  sectorId: string;
  address: string;
  membershipStatus?: 'Aktif' | 'Pindah' | 'Meninggal' | 'Tidak Aktif'; // Status Aktif
  
  // Lain-lain
  otherHistory?: string; // Riwayat Lain
  photo?: string;
  notes?: string;
  joinDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Family {
  id: string;
  headOfFamily: string;
  headMemberId: string;
  sectorId: string;
  address: string;
  memberCount: number;
  members: string[]; // Array of member IDs
  createdAt?: string; // Dipakai sbg "Dikeluarkan Tanggal" yg TETAP di Kartu Keluarga (tidak boleh ikut tanggal hari ini)
}

export interface Sector {
  id: string;
  name: string;
  leader: string;
  leaderContact: string;
  memberCount: number;
  description?: string;
  leaderId?: string;      // ID member Koordinator Sektor
  deputyLeaderId?: string; // ID member Wakil Koord. Sektor
  treasurerId?: string;   // ID member Bendahara Sektor
}

export type AgeGroup = 'Anak' | 'Pemuda' | 'Dewasa' | 'Lansia';

export interface Statistics {
  totalMembers: number;
  totalFamilies: number;
  membersBySector: { sectorId: string; count: number }[];
  membersByAge: { ageGroup: AgeGroup; count: number }[];
  birthdaysThisMonth: Member[];
}

export interface Attendance {
  id: string;
  date: string;
  serviceType: 'Minggu Pagi' | 'Minggu Sore' | 'Rabu' | 'Jumat' | 'Doa Pagi' | 'Pemuda' | 'Khusus';
  memberId: string;
  present: boolean;
  notes?: string;
}

export interface Ministry {
  id: string;
  name: string;
  description: string;
  leader: string;
  leaderMemberId: string;
  // Sumber kebenaran TUNGGAL untuk "siapa anggota komisi/unit pelayanan ini"
  // (dikelola dari MinistryManagement.tsx). Ini berbeda dari Member.pelkatStatus
  // (kategori Pelkat resmi PA/PT/GP/PKB/PKP/PKLU untuk sensus) — lihat catatan
  // di Member.pelkatStatus. Member yang dulu punya field `ministries?: string[]`
  // sudah dihapus karena tidak pernah dipakai (dead field, selalu array kosong).
  memberIds: string[];
  isActive: boolean;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  type: 'Ibadah' | 'Persekutuan' | 'Retreat' | 'Seminar' | 'Pelayanan' | 'Lainnya';
  organizer: string;
  status: 'Akan Datang' | 'Berlangsung' | 'Selesai' | 'Dibatalkan';
  pelayanan?: string;
  worshipScheduleId?: string; // Penaut opsional ke Jadwal Ibadah asal (lih. Liturgy/Resource)
  ministryId?: string; // Penaut opsional ke Ministry (Pelkat & Komisi) penyelenggara
}

export interface PrayerRequest {
  id: string;
  memberId: string;
  request: string;
  category: 'Kesehatan' | 'Keuangan' | 'Keluarga' | 'Pekerjaan' | 'Rohani' | 'Lainnya';
  isPrivate: boolean;
  status: 'Aktif' | 'Terjawab' | 'Ditutup';
  createdAt: string;
  answeredAt?: string;
  answer?: string;
}

export interface AuditDiffField {
  field: string;
  label?: string;
  oldValue: any;
  newValue: any;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  userRole?: string;
  action: 'Menambahkan' | 'Mengubah' | 'Menghapus' | 'Login' | 'Logout' | 'Export' | 'Import' | 'Restore' | 'StatusChange' | string;
  domain?: 'Member' | 'Financial' | 'Asset' | 'System' | 'Service' | 'Worship';
  entityType: 'Member' | 'Family' | 'Sector' | 'User' | 'Ministry' | 'Event' | 'Attendance' | 'Warta' | 'Baptism' | 'Sidi' | 'Marriage' | 'ServiceRequest' | 'AidDistribution' | 'Resource' | 'RoomBooking' | 'BuildingProject' | 'FinancialCategory' | 'Offering' | 'WorshipSchedule' | 'MasterData' | 'Attestation' | 'MinistrySchedule' | 'PrayerRequest' | 'Announcement' | 'FinancialRecord' | 'PettyCash' | 'PcTopUp' | 'ChurchAsset' | 'AssetMaintenance' | 'AssetLoan' | 'BankAccount' | 'Budget' | 'Liability' | 'SectorTransfer' | string;
  entityId: string;
  entityName: string;
  timestamp: string;
  details?: string;
  ipAddress?: string;
  severity?: 'normal' | 'sensitive' | 'critical';
  amount?: number; // nominal transaksi, dipakai getAuditSeverity() untuk klasifikasi kritis otomatis
  diff?: AuditDiffField[];
  beforeState?: Record<string, any>;
  afterState?: Record<string, any>;
}

// New types for enhanced features

export interface Notification {
  id: string;
  type: 'birthday' | 'event' | 'prayer' | 'announcement' | 'attendance' | 'system' | 'disposition';
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  link?: string;
  priority?: 'low' | 'medium' | 'high';
  // Fase 3 modul Surat Menyurat: kalau terisi, notifikasi ini HANYA tampil untuk
  // user dengan id ini (lihat filter di NotificationCenter.tsx) — dipakai untuk
  // memberi tahu penerima disposisi Surat Masuk secara privat. Notifikasi lama
  // tanpa field ini (broadcast) tetap tampil untuk semua orang seperti biasa.
  targetUserId?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  authorId: string;
  authorName: string;
  targetRole?: UserRole[];
  targetSectors?: string[];
  priority: 'normal' | 'important' | 'urgent';
  createdAt: string;
  expiresAt?: string;
  isActive: boolean;
}

export interface FinancialRecord {
  id: string;
  date: string;
  type: 'income' | 'expense';
  category: string;
  amount: number;
  description: string;
  reference?: string;
  recordedBy: string;
  recordedById: string;
  createdAt: string;
}

export interface FinancialCategory {
  id: string;
  name: string;
  type: 'income' | 'expense';
  description?: string;
  reportGroup?: 'program' | 'admin' | 'pemeliharaan' | 'terikat' | null;
}

export interface MinistrySchedule {
  id: string;
  date: string;
  serviceType: string;
  ministryId: string;
  assignedMembers: {
    memberId: string;
    role: string;
  }[];
  notes?: string;
}


export interface ThemePreference {
  mode: 'light' | 'dark' | 'auto';
  primaryColor?: string;
}

// ========================================
// MODUL BARU: Peribadahan & Kegiatan
// ========================================

export type WorshipType = string;

export interface WorshipOfficerGroup {
  category: string; // label kategori petugas, mengikuti Master Data "kategori_petugas_ibadah"
  names: string[];
}

export interface WorshipSchedule {
  id: string;
  type: WorshipType;
  category?: string;
  title: string;
  date: string;
  time: string;
  location: string;
  /** @deprecated dipertahankan utk kompatibilitas data lama, sumber utama sekarang `officers` */
  preacher?: string;
  /** @deprecated lihat `officers` */
  liturgist?: string;
  /** @deprecated lihat `officers` */
  worship_leader?: string;
  /** @deprecated lihat `officers` */
  pianist?: string;
  officers?: WorshipOfficerGroup[]; // Petugas Ibadah per kategori (bisa >1 nama per kategori)
  sermon_theme?: string;
  bible_verse?: string;
  description?: string;
  status?: 'Terjadwal' | 'Berlangsung' | 'Selesai' | 'Dibatalkan';
  createdAt: string;
  updatedAt?: string;
}

export interface Warta {
  id: string;
  week: number;
  month: number;
  year: number;
  title: string;
  date: string;
  coverImage?: string;
  sections: {
    id: string;
    title: string;
    content: string;
    order: number;
  }[];
  announcements: string[];
  worshipSchedules: string[]; // reference to WorshipSchedule IDs
  published: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Liturgy {
  id: string;
  date: string;
  worshipType: WorshipType;
  theme: string;
  scripture: {
    book: string;
    chapter: number;
    verse: string;
  }[];
  hymns: {
    type: 'opening' | 'offering' | 'communion' | 'closing';
    book: 'Gita Bakti' | 'Kidung Jemaat' | 'Lainnya';
    number: string;
    title: string;
  }[];
  liturgyOrder: {
    order: number;
    title: string;
    content?: string;
  }[];
  sermon?: {
    title: string;
    preacher: string;
    summary?: string;
  };
  /** Referensi ke WorshipSchedule — jadwal ibadah yang liturgi ini susun tata ibadahnya */
  worshipScheduleId?: string;
  createdAt: string;
}

// ========================================
// MODUL BARU: Keuangan & Persembahan
// ========================================

export type OfferingType = 'Mingguan' | 'Syukur' | 'Persepuluhan' | 'Pembangunan' | 'Diakonia' | 'Lainnya';
export type PaymentMethod = string;

export interface Offering {
  id: string;
  type: OfferingType;
  amount: number;
  paymentMethod: PaymentMethod;
  donorName?: string;
  donorPhone?: string;
  donorEmail?: string;
  memberId?: string;
  date: string;
  description?: string;
  qrisReference?: string;
  /** Referensi ke finance.qris_codes.id (Data QRIS di Master Data Finance) --
   *  kode QRIS spesifik yang dipakai jemaat/donatur untuk transfer, kalau
   *  dipilih dari daftar (bukan cuma diketik manual di qrisReference).
   *  qrisCodeLabel disalin sebagai snapshot pada saat input supaya riwayat
   *  persembahan lama tetap menampilkan nama yang benar meski kode itu
   *  kemudian di-rename atau dinonaktifkan di Master Data Finance. */
  qrisCodeId?: string;
  qrisCodeLabel?: string;
  createdAt: string;
  /** Diisi otomatis oleh fitur "Setor ke Buku Besar" (OfferingsQRIS.tsx /
   *  server/routes/financeTransaction.ts POST /deposit-offerings) begitu
   *  persembahan ini sudah diagregasi jadi transaksi Finance Add-on —
   *  mencegah persembahan yang sama disetor dua kali. */
  depositedTransactionId?: string;
  depositedAt?: string;
}

export interface BuildingProject {
  id: string;
  name: string;
  description: string;
  targetAmount: number;
  collectedAmount: number;
  startDate: string;
  targetDate: string;
  status: 'Planning' | 'Active' | 'Completed' | 'On Hold';
  progress: number; // percentage
  expenses: {
    id: string;
    description: string;
    amount: number;
    date: string;
    receipt?: string;
  }[];
  donations: string[]; // reference to Offering IDs
  createdAt: string;
  updatedAt: string;
}

// ========================================
// MODUL BARU: Pelayanan Kasih & Diakonia
// ========================================

export type ServiceRequestType = 'Kunjungan' | 'Doa Khusus' | 'Pelayanan Duka' | 'Konseling' | 'Lainnya';
export type ServiceStatus = 'Pending' | 'Scheduled' | 'Completed' | 'Cancelled';

export interface ServiceRequest {
  id: string;
  type: ServiceRequestType;
  requestedBy: string;
  memberId?: string;
  phone: string;
  address: string;
  preferredDate?: string;
  preferredTime?: string;
  description: string;
  status: ServiceStatus;
  assignedTo?: string; // user ID (majelis/pendeta)
  scheduledDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type AidType = 'Ekonomi' | 'Beasiswa' | 'Kesehatan' | 'Bencana' | 'Lainnya';
export type AidStatus = 'Pengajuan' | 'Verifikasi' | 'Disetujui' | 'Ditolak' | 'Disalurkan';

export interface AidDistribution {
  id: string;
  type: AidType;
  recipientName: string;
  memberId?: string;
  serviceRequestId?: string; // audit gap fix: jejak balik ke Permohonan Diakonia asal
  phone: string;
  address: string;
  amount?: number;
  description: string;
  reason: string;
  status: AidStatus;
  requestedDate: string;
  approvedBy?: string;
  approvedDate?: string;
  distributedDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

// ========================================
// MODUL BARU: Komunikasi & Pembinaan
// ========================================

export type ResourceType = 'Khotbah' | 'Materi PJJ' | 'Artikel' | 'Video' | 'Audio' | 'Dokumen';
export type ResourceCategory = 'Pembinaan' | 'Liturgi' | 'Musik' | 'Administrasi' | 'Lainnya';

export interface Resource {
  id: string;
  title: string;
  type: ResourceType;
  category: ResourceCategory;
  description?: string;
  author?: string;
  uploadedBy?: string;
  /** LEGACY: dulu diisi blob: URL sementara dari simulasi upload di client --
   *  tidak lagi dipakai untuk materi baru (lihat fileId/externalUrl). Field
   *  ini dibiarkan ada supaya record lama yang mungkin masih menyimpannya
   *  tidak error, tapi jangan ditulisi lagi dari kode baru. */
  fileUrl?: string;
  /** Referensi ke koleksi resourceFiles (PDF/DOC yang benar-benar tersimpan
   *  sebagai base64, mirip AssetDocument) -- dipakai untuk type Khotbah,
   *  Materi PJJ, Artikel, Dokumen. */
  fileId?: string;
  /** Link eksternal (YouTube, Google Drive, SoundCloud, dst.) -- dipakai
   *  untuk type Video & Audio. Filenya sengaja TIDAK disimpan di database
   *  (server database hanya 1 CPU/512MB), jadi tidak ada upload untuk
   *  kedua type ini, hanya link. */
  externalUrl?: string;
  fileSize?: string;
  duration?: string;
  thumbnailUrl?: string;
  tags: string[];
  downloads: number;
  views: number;
  publishedDate: string;
  createdAt: string;
  /** Nats Alkitab — hanya relevan untuk type 'Khotbah' */
  bibleVerse?: string;
  /** Naskah lengkap khotbah — hanya relevan untuk type 'Khotbah' */
  fullTranscript?: string;
  /** Referensi ke WorshipSchedule — jadwal ibadah tempat khotbah ini disampaikan (khusus type 'Khotbah') */
  worshipScheduleId?: string;
}

export type RoomType = 'Ruang Ibadah' | 'Aula' | 'Ruang Kelas' | 'Ruang Pertemuan' | 'Lainnya';
export type BookingStatus = 'Pending' | 'Approved' | 'Rejected' | 'Completed' | 'Cancelled';
export type RoomBookingStatus = BookingStatus;

export interface RoomBooking {
  id: string;
  roomName: string;
  roomType: RoomType;
  bookedBy: string;
  memberId?: string; // opsional: peminjam yang juga anggota jemaat terdaftar
  organization?: string; // unit kategorial
  phone: string;
  email?: string;
  purpose: string;
  date: string;
  startTime: string;
  endTime: string;
  attendees: number;
  facilities?: string[]; // sound system, projector, dll
  status: BookingStatus;
  approvedBy?: string;
  approvedDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

// ========================================
// MODUL TAMBAHAN: Atestasi
// ========================================

export type AttestationType = 'Pindah Masuk' | 'Pindah Keluar';
export type AttestationStatus = 'Diajukan' | 'Diproses' | 'Selesai' | 'Ditolak';

export interface Attestation {
  id: string;
  type: AttestationType;
  memberId: string;
  memberName: string;
  fromChurch: string;
  toChurch: string;
  reason: string;
  requestDate: string;
  processedBy?: string;
  processedDate?: string;
  completedDate?: string;
  status: AttestationStatus;
  letterNumber?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  familyId?: string; // diisi kalau atestasi ini diajukan sekaligus untuk 1 keluarga (batch) - setiap anggota tetap punya record sendiri, familyId menandai mereka sebagai satu pengajuan
  // ── Kelengkapan Atestasi Masuk (gap-fix Sept 2026) ──────────────────────────
  // Field di bawah ini HANYA relevan untuk type 'Pindah Masuk' — orang yang
  // atestasi masuk seringkali belum terdaftar di Database Warga sama sekali,
  // jadi data kontak/domisili ini ditangkap di sini dulu, lalu dipakai untuk
  // pre-fill saat mendaftarkan mereka sebagai anggota baru (lihat
  // PendingMemberDraft di bawah). Untuk 'Pindah Keluar' field ini dibiarkan
  // kosong — anggotanya sudah pasti terdaftar (memberId sudah ada sejak awal).
  phone?: string;
  address?: string;
  sectorId?: string; // Sektor tujuan — dipakai utk auto-saran format No. Induk & No. KK per sektor
  memberNumber?: string; // No. Induk yang di-assign (format: TRIN-S{sektor}-{urut 5 digit})
  familyCode?: string; // No. KK / "Kel. ..." di form kertas (format: FAM_KK_TRIN_S{sektor}_{urut})
  // Checklist 9 syarat dokumen Atestasi Masuk, key = id tetap (lihat
  // DOCUMENT_CHECKLIST_ITEMS di AttestationDatabase.tsx), value = sudah
  // lengkap/belum. Disimpan by-id (bukan teks label) supaya tidak rusak kalau
  // labelnya nanti diedit di suatu tempat.
  documentChecklist?: Record<string, boolean>;
}

// ========================================
// MODUL TAMBAHAN: Sakramen (Baptis, Sidi, Pernikahan)
// ========================================

export type BaptismType = 'Anak' | 'Dewasa';
export type BaptismStatus = 'Terjadwal' | 'Selesai' | 'Ditunda' | 'Dibatalkan';

export interface Baptism {
  id: string;
  memberId: string;
  memberName: string;
  type: BaptismType;
  baptismDate: string;
  baptismPlace: string;
  minister: string; // Pendeta
  witness1?: string;
  witness2?: string;
  parents?: {
    fatherName: string;
    motherName: string;
  };
  certificateNumber?: string;
  status: BaptismStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type SidiStatus = 'Terjadwal' | 'Selesai' | 'Ditunda' | 'Dibatalkan';

export interface Sidi {
  id: string;
  memberId: string;
  memberName: string;
  sidiDate: string;
  sidiPlace: string;
  minister: string; // Pendeta
  baptismDate: string; // Tanggal baptis sebelumnya
  baptismPlace: string;
  certificateNumber?: string;
  status: SidiStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type MarriageStatus = 'Terjadwal' | 'Selesai' | 'Ditunda' | 'Dibatalkan';

export interface Marriage {
  id: string;
  groomMemberId?: string;
  groomName: string;
  groomBirthDate: string;
  groomBaptismDate?: string;
  brideMemberId?: string;
  brideName: string;
  brideBirthDate: string;
  brideBaptismDate?: string;
  marriageDate: string;
  marriagePlace: string;
  minister: string; // Pendeta
  witness1?: string;
  witness2?: string;
  civilRegistrationNumber?: string; // No. Akta Sipil
  civilRegistrationDate?: string;
  certificateNumber?: string; // No. Surat Nikah Gereja
  status: MarriageStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

// ========================================
// Arsip Sensus Jemaat (snapshot tahunan, untuk perbandingan tahun-ke-tahun)
// ========================================
export interface SensusSnapshotSectorRow {
  name: string;
  fullName: string;
  total: number;
  laki: number;
  perempuan: number;
  keluarga: number;
  aktif: number;
  baptis: number;
  sidi: number;
  tamu: number;
  simpatisan: number;
}

export interface SensusSnapshot {
  id: string; // format: `sensus-${year}` — satu arsip per tahun
  year: number;
  archivedAt: string; // ISO timestamp saat diarsipkan
  archivedBy?: string; // nama/username yang mengarsipkan

  totalMembers: number;
  totalFamilies: number;
  totalSectors: number;
  maleCount: number;
  femaleCount: number;

  statusData: { name: string; value: number }[]; // Aktif/Tidak Aktif/Pindah/Meninggal
  membershipTypeData: { name: string; value: number }[]; // Warga Jemaat/Tamu/Simpatisan
  maritalData: { name: string; value: number }[];
  ageGroups: { name: string; value: number }[];

  baptismCount: number; // total sudah baptis (kumulatif s.d. tanggal arsip)
  sidiCount: number; // total sudah sidi (kumulatif s.d. tanggal arsip)

  baptismsThisYear: number;
  sidisThisYear: number;
  marriagesThisYear: number;

  sectorSensus: SensusSnapshotSectorRow[];
}

// ========================================
// Consolidated Report Center — Arsip Tahunan
// ========================================
export interface ConsolidatedReportSnapshot {
  id: string; // format: `report-center-${year}-${period}` — satu arsip per kombinasi tahun+periode
  year: number;
  period: string; // 'annual' | 'semester1' | 'semester2' | 'q1' | 'q2' | 'q3' | 'q4'
  archivedAt: string; // ISO timestamp saat diarsipkan
  archivedBy?: string;

  selectedSector: string;
  moduleIds: string[]; // modul yang disertakan saat diarsipkan

  totalMembers: number;
  totalFamilies: number;
  totalIncome: number;
  totalExpense: number;
  totalCashBalance: number;
  totalAssetBookValue: number;
  baptisEvents: number;
  sidiEvents: number;
  marriageEvents: number;
  worshipCount: number;
  eventsCount: number;
  aidTotalDistributed: number;
  aidRecipientsCount: number;
}

// ========================================
// Petty Cash
// ========================================
export type PettyCashStatus = 'Lunas' | 'Pending';

export interface PettyCash {
  id: string;
  date: string;
  category: string;
  description: string;
  amount: number;
  payTo: string;
  receiptNo: string;
  status: PettyCashStatus;
  createdBy: string;
  createdAt: string;
}

export interface PcTopUp {
  id: string;
  date: string;
  amount: number;
  source: string;
  description: string;
  approvedBy: string;
  createdBy: string;
  createdAt: string;
}

// ========================================
// Church Asset Management
// ========================================
export type AssetCategory = 'Tanah' | 'Bangunan' | 'Kendaraan' | 'Inventaris' | 'Elektronik' | 'Peralatan Ibadah' | 'Lainnya';
export type AssetCondition = 'Baik' | 'Cukup Baik' | 'Rusak Ringan' | 'Rusak Berat' | 'Tidak Layak';
export type AcquisitionMethod = 'Pembelian' | 'Donasi' | 'Hibah' | 'Pembangunan' | 'Wakaf';
export type MaintenanceType = 'Perawatan Rutin' | 'Perbaikan' | 'Penggantian Komponen' | 'Inspeksi';
export type MaintenanceResult = 'Selesai' | 'Dalam Proses' | 'Perlu Tindak Lanjut';
export type AssetLoanStatus = 'Tersedia' | 'Dipinjam' | 'Dalam Pemeliharaan';

export interface MaintenanceRecord {
  id: string;
  assetId: string;
  date: string;
  type: MaintenanceType;
  description: string;
  cost: number;
  technician: string;
  result: MaintenanceResult;
  notes?: string;
}

export interface ChurchAsset {
  id: string;
  assetCode: string;
  name: string;
  category: AssetCategory;
  description?: string;
  location: string;
  condition: AssetCondition;
  acquisitionDate: string;
  acquisitionValue: number;
  acquisitionMethod: AcquisitionMethod;
  usefulLifeYears: number;
  responsiblePerson?: string;
  memberId?: string;
  ministryUnit?: string;
  serialNumber?: string;
  vendor?: string;
  notes?: string;
  photo?: string;
  loanStatus?: AssetLoanStatus;
  borrowedById?: string;
  borrowedByName?: string;
  loanDate?: string;
  expectedReturnDate?: string;
  loanNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface LoanHistoryRecord {
  id: string;
  assetId: string;
  assetName?: string;
  assetCode?: string;
  borrowedById?: string;
  borrowedByName: string;
  loanDate: string;
  expectedReturnDate?: string;
  actualReturnDate?: string;
  loanNotes?: string;
  status: 'Aktif' | 'Dikembalikan' | 'Terlambat';
}

// ========================================
// Keuangan: Rekening Bank & Anggaran
// ========================================
export type BankAccountType = string;

export interface BankAccount {
  id: string;
  bankName: string;
  accountName: string;
  accountNumber: string;
  balance: number;
  type: BankAccountType;
  color: string;
  lastUpdated: string;
}

export interface Budget {
  id: string;
  category: string;
  type: 'income' | 'expense';
  budgeted: number;
  year: number;
}

// ========================================
// Livestream & Reminder Ibadah
// ========================================
export type LivestreamPlatform = 'YouTube' | 'Zoom' | 'Google Meet' | 'Facebook Live' | 'Lainnya';

export interface LivestreamLink {
  id: string;
  scheduleId: string;
  title: string;
  date: string;
  time: string;
  platform: LivestreamPlatform;
  url: string;
  isActive: boolean;
  views: number;
}

export interface ReminderSetting {
  id: string;
  name: string;
  enabled: boolean;
  timing: string;
  channel: string;
  serviceType: string;
  /** Menit sebelum jadwal ibadah untuk memicu notifikasi in-app otomatis (lihat efek pengecekan
   * reminder di AppContext). Opsional untuk kompatibilitas data lama yang belum punya lead time
   * terstruktur -- reminder tanpa field ini hanya bisa dites manual, tidak terpicu otomatis. */
  leadMinutes?: number;
}

export interface Liability {
  id: string;
  nama: string;
  nilai: number;
  kategori: 'Jangka Pendek' | 'Jangka Panjang';
}

export interface FiscalYearSetting {
  id: string;
  year: number;
  asetNetoAwal: number;
  investasiPeralatan?: number;
  investasiGedung?: number;
  notes?: string;
}

export interface SectorTransfer {
  id: string;
  memberId: string;
  memberName: string;
  fromSectorId: string;
  fromSectorName: string;
  toSectorId: string;
  toSectorName: string;
  reason: string;
  requestDate: string;
  processedDate?: string | null;
  status: 'Pending' | 'Diproses' | 'Selesai';
  processedBy?: string | null;
  notes?: string;
  familyId?: string; // diisi kalau mutasi ini diajukan sekaligus untuk 1 keluarga (batch) - setiap anggota tetap punya record sendiri, familyId menandai mereka sebagai satu pengajuan
}

export interface Room {
  id: string;
  name: string;
  roomType?: RoomType; // opsional untuk kompatibilitas data lama; fallback 'Lainnya' kalau kosong
  capacity: number;
  facilities: string[];
  location?: string;
  isActive: boolean;
}

export interface CustomRole {
  id: string;
  name: string;
  description: string;
  tanggung: string;
  warna: string;
  modulePermissions?: Record<string, string[]>;
}

export interface BuiltinRoleOverride {
  id: string;
  role: string;
  desc: string;
  tanggung: string;
  warna: string;
}
// ============================================================
// MODUL SURAT-MENYURAT — Fase 1 (Fondasi & Master Data)
// ============================================================
// Jenis surat (jenis_surat_keluar / jenis_surat_masuk) sengaja jadi Master Data
// biasa (lihat MasterDataCategory di atas) supaya admin bebas menambah/mengubah
// sendiri — beda dengan status alur kerja (Draft/Diajukan/Ditandatangani, dst)
// yang nanti tetap union type tetap di kode (bukan Master Data), karena status
// itu menggerakkan logika alur kerja & immutability, bukan sekadar label.

/** Profil & kop surat organisasi — single/few-record settings collection,
 *  polanya sama seperti FiscalYearSetting. Dibangun kosong, diisi admin sendiri
 *  lewat halaman Pengaturan Surat Menyurat (tab "Kop Surat"). */
export interface OrgLetterhead {
  id: string; // konvensi: id tetap 'default' (single record)
  churchName?: string;
  churchCode?: string; // dipakai sebagai token {kodeGereja} di format nomor surat
  address?: string;
  phone?: string;
  email?: string;
  logoData?: string; // base64 (tanpa prefix data URL), PNG/JPG
  logoMimeType?: string;
  updatedAt?: string;
  updatedBy?: string;
}

/** Template surat keluar. Isi (bodyTemplate) & manajemen penuhnya dibangun di
 *  Fase 2 bersamaan alur pembuatan surat — di Fase 1 baru collection & tipenya
 *  yang didaftarkan supaya jenisSuratId (Master Data) sudah bisa dirujuk. */
export interface LetterTemplate {
  id: string;
  name: string;
  jenisSuratId: string; // = id dari MasterDataItem berkategori 'jenis_surat_keluar'
  bodyTemplate?: string; // placeholder: {namaPenerima} {tanggal} {perihal} {nomorSurat} dst
  isActive: boolean;
  createdBy?: string;
  createdAt?: string;
}

/** Konfigurasi format nomor surat otomatis — satu record per jenis surat.
 *  Token yang didukung endpoint generator: {urut}, {urut:N} (zero-pad N digit),
 *  {jenis} (kode jenis surat), {kodeGereja}, {bulanRomawi}, {tahun}, {sektor}. */
export interface LetterNumberFormat {
  id: string;
  jenisSuratId: string; // = id dari MasterDataItem berkategori 'jenis_surat_keluar'
  pattern: string; // contoh: "{urut:3}/{jenis}/{kodeGereja}/{bulanRomawi}/{tahun}"
  resetPeriod: 'tahunan' | 'bulanan' | 'tidak_pernah';
  updatedAt?: string;
  updatedBy?: string;
}

/** Counter internal atomik di balik LetterNumberFormat — TIDAK untuk diedit
 *  manual lewat UI. id = scope key (mis. "UND-2026" atau "UND-09-2026"
 *  tergantung resetPeriod). Diakses lewat endpoint server yang mengunci baris
 *  (SELECT ... FOR UPDATE) supaya tidak ada nomor kembar saat submit bersamaan. */
export interface LetterNumberCounter {
  id: string;
  lastNumber: number;
  updatedAt: string;
}

/** Gambar tanda tangan & cap. type 'signature' = TTD milik satu user (ownerType
 *  'user', ownerId = User.id); type 'stamp' = cap organisasi (ownerType
 *  'organization', ownerId = 'org' — satu cap untuk semua surat, sesuai
 *  keputusan awal; struktur ownerId ini tetap mendukung banyak cap kalau nanti
 *  dibutuhkan, cukup pakai ownerId lain, tanpa ubah skema). */
export interface SignatureAsset {
  id: string;
  ownerType: 'user' | 'organization';
  ownerId: string;
  type: 'signature' | 'stamp';
  imageData: string; // base64 (tanpa prefix data URL), idealnya PNG transparan
  mimeType: string;
  isActive: boolean;
  uploadedAt: string;
  uploadedBy?: string;
}

/** Daftar Pejabat Penandatangan -- kurasi terpisah dari daftar User penuh.
 *  Sebelumnya tab "TTD & Cap" otomatis menampilkan SEMUA user di sistem
 *  (termasuk yang tidak pernah menandatangani surat), tanpa cara memilih
 *  siapa saja yang benar-benar berwenang. SigningOfficial cuma menandai
 *  SUBSET user mana yang tampil di daftar itu -- menambah/menghapus dari
 *  sini TIDAK mengubah/menghapus akun User itu sendiri, dan TIDAK memengaruhi
 *  alur tandatangan Surat Keluar (OutgoingLetters.tsx tetap mencocokkan
 *  SignatureAsset.ownerId === currentUser.id saat proses tandatangan --
 *  jadi tetap cuma pemilik akun yang login yang bisa pakai TTD-nya sendiri). */
export interface SigningOfficial {
  id: string;
  userId: string; // ref User.id
  jabatan?: string; // jabatan/gelar resmi saat menandatangani, mis. "Ketua Majelis" -- opsional, kalau kosong tampilkan role user apa adanya
  isActive: boolean;
  order?: number;
  addedBy?: string;
  addedAt: string;
}

// ============================================================
// MODUL SURAT-MENYURAT — Fase 2 (Surat Keluar, alur inti)
// ============================================================
/** Status alur kerja Surat Keluar. Tidak ada status 'Ditolak' terpisah —
 *  penolakan di tahap Diajukan/Diperiksa mengembalikan status ke 'Draft'
 *  (dengan rejectReason terisi), bukan status baru — lihat catatan di
 *  OutgoingLetter.status di bawah dan Bagian 4 rencana Fase 2. */
export type OutgoingLetterStatus =
  | 'Draft'
  | 'Diajukan'
  | 'Diperiksa'
  | 'Ditandatangani'
  | 'Terkirim'
  | 'Diarsipkan';

/** Surat Keluar — inti Fase 2. Field yang berhubungan dengan tahap
 *  Diperiksa/Ditandatangani/Terkirim/Diarsipkan (letterNumber, checkedBy,
 *  signedBy, finalPdfData, dst) HANYA diisi lewat endpoint transisi
 *  /api/outgoing-letters/:id/... (server/routes/outgoingLetters.ts) — PUT
 *  generik /api/data/outgoingLetters/:id ditolak begitu status sudah
 *  lewat 'Draft', supaya integritas nomor surat & TTD tidak bisa "diam-diam"
 *  diubah lewat jalur CRUD biasa (lihat guard di server/routes/data.ts). */
export interface OutgoingLetter {
  id: string;
  status: OutgoingLetterStatus;
  letterNumber?: string; // baru terisi setelah tahap Diperiksa (nomor di-generate atomik)
  letterDate: string;
  templateId?: string; // ref LetterTemplate — opsional, bisa juga ditulis bebas tanpa template
  jenisSuratId: string; // ref MasterDataItem kategori 'jenis_surat_keluar'
  subject: string; // perihal
  recipientName: string;
  recipientInstitution?: string;
  body: string; // isi surat setelah placeholder template terisi
  sectorId?: string; // opsional — kalau surat dibuat per-sektor
  memberId?: string; // opsional — ref Member.id kalau surat ini ditujukan ke/menyangkut satu jemaat tertentu (gap-fix Sept 2026: dipakai auto-link ke Dokumen Jemaat saat Diarsipkan, lihat server/lib/memberDocumentSync.ts)

  createdBy: string;
  createdAt: string;
  updatedAt?: string;

  submittedBy?: string;
  submittedAt?: string;

  checkedBy?: string;
  checkedAt?: string;

  signedBy?: string;
  signedAt?: string;
  signatureAssetId?: string;
  stampAssetId?: string;
  finalPdfData?: string; // base64 PDF hasil render final — immutable setelah Ditandatangani

  sentAt?: string;
  sentVia?: string; // opsional: pos/email/diambil langsung

  archivedAt?: string;
  archivedBy?: string;

  rejectReason?: string; // alasan "Kembalikan" terbaru (dari tahap Diajukan/Diperiksa)

  relatedModule?: string; // opsional: mis. 'Atestasi', 'Sakramen', 'IncomingLetter'
  relatedId?: string;
  replacesLetterId?: string; // opsional: kalau surat ini revisi/pengganti surat yang sudah ditandatangani
}

/** Lampiran pendukung Surat Keluar — pola sama seperti attestationDocuments
 *  (base64, maks 2MB, PDF saja — lihat DOCUMENT_COLLECTIONS di data.ts). */
export interface OutgoingLetterAttachment {
  id: string;
  letterId: string; // ref OutgoingLetter.id
  fileName: string;
  fileSize: number;
  mimeType: string;
  fileData: string; // base64
  uploadedAt: string;
  uploadedBy?: string;
}

// ============================================================
// MODUL SURAT-MENYURAT — Fase 3 (Surat Masuk & Disposisi)
// ============================================================
export type IncomingLetterStatus =
  | 'Diterima'
  | 'Didisposisikan'
  | 'DitindakLanjuti'
  | 'Selesai'
  | 'Diarsipkan';

/** Diisi/diubah HANYA lewat PUT /api/incoming-letters/:id/disposisikan
 *  (server/routes/incomingLetters.ts) — boleh dipanggil ulang selagi status
 *  masih 'Didisposisikan' untuk mengoreksi penerima/instruksi/tenggat (surat
 *  masuk tidak punya alur "Kembalikan" seperti Surat Keluar, jadi ini jalan
 *  keluarnya kalau disposisi awal keliru), tapi terkunci begitu status sudah
 *  'DitindakLanjuti' ke atas. */
export interface IncomingLetterDisposition {
  assignedToUserId: string;
  instruction: string;
  dueDate?: string;
  assignedBy?: string;
  assignedAt?: string;
}

/** Surat Masuk — Fase 3. Beda penting dari OutgoingLetter: letterNumber di sini
 *  adalah nomor DARI PENGIRIM (diketik manual saat mencatat), BUKAN hasil
 *  generateLetterNumber() — surat masuk tidak melalui penomoran internal
 *  gereja. Field tahap-lanjut (disposisi, followUp*, completedAt/By,
 *  archivedAt/By) HANYA diisi lewat endpoint transisi khusus di
 *  server/routes/incomingLetters.ts — PUT/DELETE generik ke
 *  /api/data/incomingLetters/:id ditolak begitu status sudah lewat 'Diterima'
 *  (guard yang sama prinsipnya dengan outgoingLetters, lihat data.ts). */
export interface IncomingLetter {
  id: string;
  status: IncomingLetterStatus;
  letterNumber?: string;
  receivedDate: string;
  senderName: string;
  senderInstitution?: string;
  subject: string;
  category?: string; // ref MasterDataItem kategori 'jenis_surat_masuk'
  memberId?: string; // opsional — ref Member.id kalau surat ini dari/menyangkut satu jemaat tertentu (gap-fix Sept 2026: dipakai auto-link ke Dokumen Jemaat saat Diarsipkan)
  notes?: string;

  disposisi?: IncomingLetterDisposition;

  followUpNotes?: string;
  followUpAt?: string;
  followUpBy?: string;

  completedAt?: string;
  completedBy?: string;

  archivedAt?: string;
  archivedBy?: string;

  createdBy: string;
  createdAt: string;
  updatedAt?: string;
}

/** Lampiran hasil scan Surat Masuk — pola sama outgoingLetterAttachments
 *  (base64, maks 2MB, PDF saja). Sengaja dibuat sebagai collection terpisah
 *  (bukan satu field scanFileData tunggal di record) supaya satu surat masuk
 *  bisa punya lebih dari satu halaman/lampiran scan, konsisten dengan pola
 *  Surat Keluar Fase 2. */
export interface IncomingLetterAttachment {
  id: string;
  letterId: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  fileData: string;
  uploadedAt: string;
  uploadedBy?: string;
}

// ============================================================
// MODUL SURAT-MENYURAT — Prefill lintas-modul (gap-fix Sept 2026)
// ============================================================
/** Payload sementara (in-memory saja lewat AppContext.pendingLetterDraft, TIDAK
 *  pernah disimpan ke server) yang membawa data dari record Sakramen/Atestasi
 *  ke form Surat Keluar baru saat staf klik tombol "Buat Surat" di halaman
 *  asalnya (SacramentDatabase.tsx / AttestationDatabase.tsx). OutgoingLetters.tsx
 *  mengonsumsinya lewat efek satu kali di awal render lalu langsung memanggil
 *  setPendingLetterDraft(null) supaya tidak "nyangkut" kalau staf pindah ke
 *  halaman Surat Keluar lewat jalur lain sesudahnya. */
export interface PendingLetterDraft {
  relatedModule: 'Sakramen' | 'Atestasi' | 'RoomBooking' | 'ServiceRequest' | 'AidDistribution';
  relatedId: string;
  memberId?: string;
  recipientName?: string;
  recipientInstitution?: string;
  subject?: string;
  body?: string;
}

/** Payload sementara (in-memory saja lewat AppContext.pendingMemberDraft, TIDAK
 *  pernah disimpan ke server) yang membawa data dari Atestasi Masuk ke modal
 *  Tambah Anggota baru di Database Jemaat, saat atestasi ditandai Selesai
 *  tapi orangnya belum terdaftar (memberId kosong). MemberDatabase.tsx
 *  mengonsumsinya lewat efek satu kali lalu langsung memanggil
 *  setPendingMemberDraft(null) — pola sama persis dengan PendingLetterDraft. */
export interface PendingMemberDraft {
  relatedModule: 'Atestasi';
  relatedId: string;
  fullName: string;
  phone?: string;
  address?: string;
  familyCode?: string;
  sectorId?: string;
  memberNumber?: string;
}
