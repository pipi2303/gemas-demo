import { Router, Response } from 'express';
import crypto from 'crypto';
import { getAllCollectionCounts, truncateAll, getPool } from '../lib/db.js';
import { requireAuth, requireRole, AuthRequest } from '../middleware/auth.js';
import { logger } from '../lib/logger.js';
import { recordAuditEntry } from '../lib/auditLog.js';
import { getJwtSecret } from '../lib/jwt.js';

const ENCRYPTION_MARKER = 'GEMAS_ENC_V1:';

function getEncryptionKey(): Buffer {
  // Security fix: sebelumnya fallback ke literal string 'fallback' sendiri
  // (terpisah dari & lebih lemah daripada fallback JWT di jwt.ts) kalau
  // JWT_SECRET tidak di-set -- disatukan lewat getJwtSecret() supaya satu
  // sumber kebenaran, dan supaya production tanpa JWT_SECRET sudah gagal
  // start duluan di validateEnv() (server/index.ts), tidak pernah sampai ke sini.
  return crypto.scryptSync(getJwtSecret(), 'gemas-backup-salt', 32);
}

export function encryptData(plaintext: string): string {
  const key = getEncryptionKey();
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return ENCRYPTION_MARKER + Buffer.concat([iv, authTag, encrypted]).toString('base64');
}

function decryptData(data: string): string {
  if (!data.startsWith(ENCRYPTION_MARKER)) return data; // not encrypted
  const key = getEncryptionKey();
  const buf = Buffer.from(data.slice(ENCRYPTION_MARKER.length), 'base64');
  const iv = buf.subarray(0, 16);
  const authTag = buf.subarray(16, 32);
  const encrypted = buf.subarray(32);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  return decipher.update(encrypted) + decipher.final('utf8');
}

const router = Router();

// Security fix: sebelumnya cuma requireAuth (role apa pun yang login bisa
// lihat jumlah baris tiap koleksi, termasuk 'users'/'financialRecords') --
// info ini bukan risiko tulis, tapi tidak ada alasan modul Admin Sistem
// membocorkan ukuran data ke role selain Admin. Disamakan Admin-only
// seperti tiga endpoint backup lain di file ini.
router.get('/counts', requireAuth, requireRole('Admin'), async (_req: AuthRequest, res: Response) => {
  try {
    const counts = await getAllCollectionCounts();
    res.json(counts);
  } catch (err) {
    logger.error('Backup counts error', { message: String(err) });
    res.status(500).json({ error: 'Gagal mengambil data' });
  }
});

// GET /api/backup/export — export semua data sebagai JSON
router.get('/export', requireAuth, requireRole('Admin'), async (req: AuthRequest, res: Response) => {
  try {
    const result = await getPool().query<{ collection: string; id: string; data: string }>(
      'SELECT collection, id, data FROM gemas_store ORDER BY collection, updated_at ASC'
    );

    const grouped: Record<string, unknown[]> = {};
    for (const row of result.rows) {
      if (!grouped[row.collection]) grouped[row.collection] = [];
      grouped[row.collection].push(JSON.parse(row.data));
    }

    // Strip passwords dari export
    if (grouped.users) {
      grouped.users = (grouped.users as any[]).map(({ password: _pw, ...u }) => u);
    }

    const filename = `gemas-backup-${new Date().toISOString().slice(0, 10)}.json`;
    const collectionCount = Object.keys(grouped).length;
    logger.info('Data exported', { user: req.user!.username, collections: collectionCount });
    const payload = JSON.stringify({ exportedAt: new Date().toISOString(), data: grouped });
    const encrypted = encryptData(payload);
    const encFilename = filename.replace('.json', '.enc.json');
    await recordAuditEntry(req, {
      action: 'Export',
      domain: 'System',
      entityType: 'Backup',
      entityId: encFilename,
      entityName: encFilename,
      details: `Export backup terenkripsi berisi ${collectionCount} koleksi data.`,
      severity: 'sensitive',
    });
    res.setHeader('Content-Disposition', `attachment; filename="${encFilename}"`);
    res.setHeader('Content-Type', 'text/plain');
    res.send(encrypted);
  } catch (err) {
    logger.error('Export error', { message: String(err) });
    res.status(500).json({ error: 'Gagal export data' });
  }
});

router.delete('/all', requireAuth, requireRole('Admin'), async (req: AuthRequest, res: Response) => {
  try {
    await truncateAll();
    logger.warn('All data truncated', { user: req.user!.username });
    // Dicatat SETELAH truncateAll() selesai — truncateAll mengosongkan
    // seluruh tabel gemas_store (termasuk collection activityLogs itu
    // sendiri), jadi kalau entry ini ditulis sebelum truncate, entry-nya
    // ikut terhapus. Ditulis sesudah, supaya justru jadi entry PERTAMA
    // di log yang sudah bersih.
    await recordAuditEntry(req, {
      action: 'Reset',
      domain: 'System',
      entityType: 'Backup',
      entityId: 'all-data',
      entityName: 'Seluruh data (semua koleksi)',
      details: 'Semua data di database direset/dikosongkan (truncate all).',
      severity: 'critical',
    });
    res.json({ ok: true });
  } catch (err) {
    logger.error('Truncate all error', { message: String(err) });
    res.status(500).json({ error: 'Gagal reset data' });
  }
});

// POST /api/backup/restore — restore data dari backup JSON
router.post('/restore', requireAuth, requireRole('Admin'), async (req: AuthRequest, res: Response) => {
  const body = req.body as { data?: Record<string, unknown[]>; encrypted?: string; clearFirst?: boolean };

  let data: Record<string, unknown[]>;
  const clearFirst = body.clearFirst ?? true;

  if (body.encrypted) {
    try {
      const decrypted = decryptData(body.encrypted);
      const backup = JSON.parse(decrypted);
      data = backup.data;
    } catch {
      return res.status(400).json({ error: 'Gagal dekripsi backup. Pastikan backup dari server yang sama.' });
    }
  } else if (body.data) {
    data = body.data;
  } else {
    return res.status(400).json({ error: 'Format backup tidak valid' });
  }

  if (!data || typeof data !== 'object') {
    return res.status(400).json({ error: 'Format backup tidak valid' });
  }

  // users: jangan overwrite supaya akses tidak hilang. customRoles &
  // rbac_permissions: SECURITY FIX -- backup yang di-restore bisa berasal dari
  // file yang sudah dimanipulasi (lihat catatan validasi di bawah, tidak ada
  // cek skema/versi/tanda tangan sama sekali selain "berhasil didekripsi/
  // JSON valid") -- kalau kedua collection ini ikut ditimpa, restore backup
  // palsu bisa diam-diam mengubah matrix hak akses & custom role jadi
  // memberi siapa pun akses Admin, tanpa preview/diff apa pun ke Admin yang
  // me-restore.
  const PROTECTED = ['users', 'customRoles', 'rbac_permissions'];
  const collections = Object.keys(data).filter(c => !PROTECTED.includes(c));

  // ATOMICITY FIX -- sebelumnya tiap query pakai getPool().query() langsung
  // (pool, bukan satu koneksi tetap), jadi BEGIN/DELETE/INSERT.../COMMIT bisa
  // saja dieksekusi di koneksi pool yang berbeda-beda -- artinya BEGIN/COMMIT
  // itu tidak benar-benar membungkus operasi delete+insert dalam satu
  // transaksi nyata. Kalau restore gagal di tengah jalan (misal 1 record
  // korup), data yang sudah sempat di-DELETE bisa hilang permanen tanpa yang
  // baru berhasil masuk. Polanya sekarang disamakan dengan batchUpsert() di
  // server/lib/db.ts: satu client yang di-checkout dari pool untuk seluruh
  // transaksi, baru dilepas di akhir.
  const client = await getPool().connect();
  let restored = 0;
  try {
    await client.query('BEGIN');

    if (clearFirst) {
      for (const col of collections) {
        await client.query('DELETE FROM gemas_store WHERE collection = $1', [col]);
      }
    }

    for (const col of collections) {
      const items = data[col] as any[];
      for (const item of items) {
        if (!item.id) continue;
        await client.query(
          `INSERT INTO gemas_store (collection, id, data, updated_at)
           VALUES ($1, $2, $3, NOW())
           ON CONFLICT (collection, id)
           DO UPDATE SET data = EXCLUDED.data, updated_at = EXCLUDED.updated_at`,
          [col, item.id, JSON.stringify(item)]
        );
        restored++;
      }
    }

    await client.query('COMMIT');
    logger.info('Data restored from backup', { user: req.user!.username, restored, collections: collections.length });
    // Dicatat SETELAH transaksi COMMIT berhasil — restore adalah operasi
    // destruktif (bisa menimpa banyak data sekaligus), jadi jejak audit
    // hanya ditulis kalau restore-nya benar-benar sukses.
    await recordAuditEntry(req, {
      action: 'Restore',
      domain: 'System',
      entityType: 'Backup',
      entityId: `restore-${Date.now()}`,
      entityName: `Restore ${collections.length} koleksi (${restored} record)`,
      details: `Restore backup: ${restored} record dipulihkan ke ${collections.length} koleksi. clearFirst=${clearFirst}.`,
      severity: 'critical',
    });
    res.json({ ok: true, restored, collections: collections.length });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    logger.error('Restore error', { message: String(err) });
    res.status(500).json({ error: 'Gagal restore data' });
  } finally {
    client.release();
  }
});

export default router;
